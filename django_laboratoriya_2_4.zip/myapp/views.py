from django.shortcuts import render

# Görünüş (view) funksiyası
def index(request):
    # myapp/index.html şablonunu qaytarır
    return render(request, 'myapp/index.html')
